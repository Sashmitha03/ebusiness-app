# Amma's Table - source code (student demo app)

Plain HTML + CSS + JavaScript single-page app (no framework, no build step, no API keys).
- `www/index.html` is the whole app. Orders are kept in the browser's localStorage on that device.
- Payments are SIMULATED. No real money is processed and no card data is collected.
- Replace the WhatsApp number (`wa.me/910000000000`) in index.html with your own.

## Run it on your laptop
Double-click `www/index.html` (opens in Chrome/Edge). Press F12 and the phone icon to see the mobile view.

## Make an Android APK (free, Windows)
Method A - PWABuilder (easiest, no Android Studio):
1. Create a free GitHub account, make a public repo, upload `www/index.html`, add `manifest.json` and a 512x512 icon, then enable Settings > Pages. You get an https link.
2. Open pwabuilder.com, paste that link, fix any manifest warnings it lists, choose Package for stores > Android > Download.
3. Unzip; use the unsigned/test APK from the package, copy to your phone and install (allow "Install unknown apps").

Method B - Capacitor (needs Node.js + Android Studio):
1. Install Node.js LTS and Android Studio.
2. In this folder: `npm init -y`, `npm i @capacitor/core @capacitor/cli @capacitor/android`
3. `npx cap init "Amma's Table" com.student.ammastable --web-dir=www`, then `npx cap add android`, `npx cap sync`
4. `npx cap open android`, then in Android Studio: Build > Build APK(s). The APK is in android/app/build/outputs/apk/debug/.
